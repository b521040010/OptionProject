try
    riskAversion=0.000002;
    %riskAversion=0.0000001;
    K=[2000:50:3000];
    %K=[2130]
    quantity=1;
    n=length(K);
     indifferencePricesForBuying=zeros(1,n);
    indifferencePricesForSelling=zeros(1,n);
    sup=zeros(1,n);
    sub=zeros(1,n);
    for i=1:n
        K(i)
        [indifferencePricesForBuying(i),~,~,~]=testComputeIndifferencePrice(riskAversion,K(i),quantity);
        indifferencePricesForBuying
        sup
        sub
    end
    indifferencePricesForBuying=indifferencePricesForBuying./(quantity*100);
    for i=1:n
        K(i)
        [indifferencePricesForSelling(i),sup(i),sub(i),~]=testComputeIndifferencePrice(riskAversion,K(i),-quantity);
        indifferencePricesForSelling
        sup
        sub
        
    end
    indifferencePricesForSelling=indifferencePricesForSelling./(-quantity*100);
         
catch
  x=1;

end
    