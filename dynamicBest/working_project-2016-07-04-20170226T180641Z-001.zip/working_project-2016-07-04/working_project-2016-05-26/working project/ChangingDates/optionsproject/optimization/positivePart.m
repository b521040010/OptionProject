function r = positivePart(x)
    r = x .* (x>=0);
end

