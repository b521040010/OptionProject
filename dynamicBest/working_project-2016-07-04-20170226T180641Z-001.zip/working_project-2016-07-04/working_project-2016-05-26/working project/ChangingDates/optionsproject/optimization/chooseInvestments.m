function chooseInvestments( marketData )
end