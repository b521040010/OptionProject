function initMosek()
global initMosekComplete;
if initMosekComplete==true;
else
    addpath 'c:\Program Files\mosek\7\toolbox\r2013a'
end
initMosekComplete = true;
end

