function testutilityoptimization()
testPortfolio();
testIndifferencePricer();
testBlackScholesModel();
testStudentTModel();
testUtilityMaximizationProblem();
testLineSearch();
testBachelierModel();
testQuadRule();
testLegendrePolynomial();
testPowerUtilityFunction();
testExponentialUtilityFunction();
testSeparableProblem();
testInstruments();
end

