javaaddpath '\\debussy.mth.kcl.ac.uk\jarmstro\javalibs\blpapi_java_3.6.1.0\bin\blpapi-3.6.1-0.jar'
bloomberg = blp;