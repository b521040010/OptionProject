javaaddpath 'C:\Users\k1455186\Downloads\blpapi3.jar'
bloomberg = blp;