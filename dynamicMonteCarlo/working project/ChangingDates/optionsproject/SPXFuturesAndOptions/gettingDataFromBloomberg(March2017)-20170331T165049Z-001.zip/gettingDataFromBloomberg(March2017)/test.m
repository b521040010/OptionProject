function test()
try
assert(1==2)
catch
    disp('ss')
end